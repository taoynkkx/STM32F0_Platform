var searchData=
[
  ['queue_5fsz',['queue_sz',['../structos_message_q_def__t.html#a8a83a3a8c0aa8057b13807d2a54077e0',1,'osMessageQDef_t::queue_sz()'],['../structos_mail_q_def__t.html#a8a83a3a8c0aa8057b13807d2a54077e0',1,'osMailQDef_t::queue_sz()']]]
];
