var structos_thread_def__t =
[
    [ "instances", "structos_thread_def__t.html#aa4c4115851a098c0b87358ab6c025603", null ],
    [ "pthread", "structos_thread_def__t.html#ad3c9624ee214329fb34e71f544a6933e", null ],
    [ "stacksize", "structos_thread_def__t.html#a950b7f81ad4711959517296e63bc79d1", null ],
    [ "tpriority", "structos_thread_def__t.html#a15da8f23c6fe684b70a73646ada685e7", null ]
];